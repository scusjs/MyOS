void io_hlt(void);
void HariMain(void)
{

fin:
	goto fin;

}
